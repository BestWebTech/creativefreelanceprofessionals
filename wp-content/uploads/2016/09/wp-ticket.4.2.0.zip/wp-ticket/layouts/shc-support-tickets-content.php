<?php global $support_tickets_count, $support_tickets_filter;
$real_post = $post;
$ent_attrs = get_option('wp_ticket_com_attr_list');
?>
<tr>
    <td class="search-results-row"><a href="<?php echo get_permalink(); ?>" target="_blank"><?php echo esc_html(emd_mb_meta('emd_ticket_id')); ?>
</a></td>
    <td class="search-results-row"><?php echo get_the_title(); ?></td>
    <td class="search-results-row"><span class="ticket-tax <?php $term_list = get_the_terms(get_the_ID() , 'ticket_status');
if (!empty($term_list)) {
	foreach ($term_list as $term) echo esc_attr($term->slug);
} ?>"><?php echo strip_tags(get_the_term_list(get_the_ID() , 'ticket_status', '', ' ', '')); ?></span></td>
    <td class="search-results-row"><span class="ticket-tax <?php $term_list = get_the_terms(get_the_ID() , 'ticket_priority');
if (!empty($term_list)) {
	foreach ($term_list as $term) echo esc_attr($term->slug);
} ?>"><?php echo strip_tags(get_the_term_list(get_the_ID() , 'ticket_priority', '', ' ', '')); ?></span></td>
    <?php echo ((shortcode_exists('wpas_woo_order_woo_ticket')) ? "
    <td class=\"search-results-row\">" . do_shortcode("[wpas_woo_order_woo_ticket con_name='woo_ticket' app_name='wp_ticket_com' type='list_div' post= " . get_the_ID() . "]") . "</td>
    " : ""); ?> <?php echo ((shortcode_exists('wpas_woo_product_woo_ticket')) ? "
    <td class=\"search-results-row\">" . do_shortcode("[wpas_woo_product_woo_ticket con_name='woo_ticket' app_name='wp_ticket_com' type='list_ol' post= " . get_the_ID() . "]") . "</td>
    " : ""); ?> <?php echo ((shortcode_exists('wpas_edd_order_edd_ticket')) ? "
    <td class=\"search-results-row\">" . do_shortcode("[wpas_edd_order_edd_ticket con_name='edd_ticket' app_name='wp_ticket_com' type='list_div' post= " . get_the_ID() . "]") . "</td>
    " : ""); ?> <?php echo ((shortcode_exists('wpas_edd_product_edd_ticket')) ? "
    <td class=\"search-results-row\">" . do_shortcode("[wpas_edd_product_edd_ticket con_name='edd_ticket' app_name='wp_ticket_com' type='list_ol' post= " . get_the_ID() . "]") . "</td>
    " : ""); ?> 
    <td class="search-results-row"><?php echo get_the_modified_date(); ?></td>
</tr>