<?php global $search_tickets_shc_count; ?></tbody>
</table>
</div>