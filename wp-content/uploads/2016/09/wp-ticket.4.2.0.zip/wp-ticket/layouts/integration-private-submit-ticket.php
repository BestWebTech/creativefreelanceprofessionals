<?php global $private_submit_ticket_filter; ?><div class="emd-container">
<?php echo do_shortcode("[submit_tickets]"); ?>
</div>