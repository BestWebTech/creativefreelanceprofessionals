<?php global $support_tickets_shc_count; ?><table class="table table-striped">
    <thead>
        <tr>
            <th class="search-results-header"><?php _e('Ticket ID', 'wp-ticket-com'); ?></th>
            <th class="search-results-header"><?php _e('Subject', 'wp-ticket-com'); ?></th>
            <th class="search-results-header"><?php _e('Status', 'wp-ticket-com'); ?></th>
            <th class="search-results-header"><?php _e('Priority', 'wp-ticket-com'); ?></th>
            <?php echo ((shortcode_exists('wpas_woo_order_woo_ticket')) ? "
            <th class=\"search-results-header\">" . __('Order', 'wp_ticket_com') . "</th>
            " : ""); ?> <?php echo ((shortcode_exists('wpas_woo_product_woo_ticket')) ? "
            <th class=\"search-results-header\">" . __('Product', 'wp_ticket_com') . "</th>
            " : ""); ?> <?php echo ((shortcode_exists('wpas_edd_order_edd_ticket')) ? "
            <th class=\"search-results-header\">" . __('Order', 'wp_ticket_com') . "</th>
            " : ""); ?> <?php echo ((shortcode_exists('wpas_edd_product_edd_ticket')) ? "
            <th class=\"search-results-header\">" . __('Download', 'wp_ticket_com') . "</th>
            " : ""); ?> 
            <th class="search-results-header"><?php _e('Updated', 'wp-ticket-com'); ?></th>
        </tr>
    </thead>
    <tbody>