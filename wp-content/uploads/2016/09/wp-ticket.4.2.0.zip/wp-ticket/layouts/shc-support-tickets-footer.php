<?php global $support_tickets_shc_count; ?></tbody>
</table>