<?php global $private_search_ticket_filter; ?><div class="emd-container">
<?php echo do_shortcode("[search_tickets]"); ?>
</div>