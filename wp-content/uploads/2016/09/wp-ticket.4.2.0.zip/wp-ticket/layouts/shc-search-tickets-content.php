<?php global $search_tickets_count;
$ent_attrs = get_option('wp_ticket_com_attr_list'); ?>
<tr>
    <td class="search-results-row"><a href="<?php echo get_permalink(); ?>" target="_blank"><?php echo esc_html(emd_mb_meta('emd_ticket_id')); ?>
</a></td>
    <td class="search-results-row"><?php echo get_the_title(); ?></td>
    <td class="search-results-row"><span class="ticket-tax <?php $term_list = get_the_terms(get_the_ID() , 'ticket_status');
if (!empty($term_list)) {
	foreach ($term_list as $term) echo esc_attr($term->slug);
} ?>"><?php echo strip_tags(get_the_term_list(get_the_ID() , 'ticket_status', '', ' ', '')); ?></span></td>
    <td class="search-results-row"><span class="ticket-tax <?php $term_list = get_the_terms(get_the_ID() , 'ticket_priority');
if (!empty($term_list)) {
	foreach ($term_list as $term) echo esc_attr($term->slug);
} ?>"><?php echo strip_tags(get_the_term_list(get_the_ID() , 'ticket_priority', '', ' ', '')); ?></span></td>
    <td class="search-results-row"><?php echo get_the_modified_date(); ?></td>
</tr>