<?php
/**
 * Notification Actions Functions
 *
 * @package     EMD
 * @copyright   Copyright (c) 2014,  Emarket Design
 * @since       1.0
 */
if (!defined('ABSPATH')) exit;
/**
 * Sends admin notifications
 *
 * @since WPAS 4.0
 *
 * @param string $app
 * @param array $mynotify
 * @param string $event
 * @param string $pid
 * @param array $rel_uniqs
 *
 */
function emd_send_notification_admin($app, $mynotify, $pid) {
	if (!empty($mynotify['admin_msg'])) {
		$mynotify['admin_msg']['message'] = emd_parse_template_tags($app, $mynotify['admin_msg']['message'], $pid);
		$mynotify['admin_msg']['subject'] = emd_parse_template_tags($app, $mynotify['admin_msg']['subject'], $pid);
		emd_send_email($mynotify['admin_msg']);
	}
}
/**
 * Sends notification if there is active entity events
 *
 * @since WPAS 4.0
 *
 * @param string $app
 * @param int $pid
 * @param string $type
 * @param string $event
 *
 */
function emd_check_notify_admin($app, $pid, $type, $event, $rel_uniqs = Array()) {
	$notify_list = get_option($app . "_notify_list");
	$mypost = get_post($pid);
	$ptype = $mypost->post_type;
	if (!empty($notify_list)) {
		foreach ($notify_list as $mynotify) {
			if ($mynotify['active'] == 1) {
				if ($type == 'entity' && $mynotify['level'] == $type && isset($mynotify['ev_' . $event]) && $mynotify['ev_' . $event] == 1 && $mynotify['entity'] == $ptype) {
					emd_send_notification_admin($app, $mynotify, $pid);
				}
			}
		}
	}
}
/**
 * Use wp_mail to send notifications
 *
 * @since WPAS 4.0
 *
 * @param array $conf_arr
 *
 */
function emd_send_email($conf_arr) {
	if(!empty($conf_arr['send_to'])){
		$from_name = get_bloginfo('name');
		$from_email = get_option('admin_email');
		$headers = "From: " . stripslashes_deep(html_entity_decode($from_name, ENT_COMPAT, 'UTF-8')) . " <$from_email>\r\n";
		$headers.= 'Content-type: text/html; charset=UTF-8' . "\r\n";
		if ($conf_arr['reply_to'] != '') {
			$headers.= "Reply-To: " . $conf_arr['reply_to'] . "\r\n";
		} else {
			$headers.= "Reply-To: " . $from_email . "\r\n";
		}
		if ($conf_arr['cc'] != '') {
			$headers.= "Cc: " . $conf_arr['cc'] . "\r\n";
		}
		if ($conf_arr['bcc'] != '') {
			$headers.= "Bcc: " . $conf_arr['bcc'] . "\r\n";
		}
		wp_mail($conf_arr['send_to'], $conf_arr['subject'], $conf_arr['message'], $headers);
	}
}
add_action('emd_notify', 'emd_check_notify_admin', 10, 5);
add_action( 'login_redirect', 'emd_login_redirect', 10, 3);
/**
 * Check if login is from a notification email and forward it to redirect if a user is logged in
 *
 * @since WPAS 4.6
 *
 */
function emd_login_redirect($redirect_to,$request, $user){
      if(preg_match('/fr_emd_notify/', $redirect_to)){
              $redirect_to = preg_replace('/fr_emd_notify.*/','',$redirect_to);
                $my_user = wp_get_current_user();
                if(!empty($my_user) && $my_user->ID != 0){
                        global $user;
                        $user = $my_user;
                        return $redirect_to;
                }
                else {
                        return $redirect_to;
                }
        }
        return $redirect_to;
}

