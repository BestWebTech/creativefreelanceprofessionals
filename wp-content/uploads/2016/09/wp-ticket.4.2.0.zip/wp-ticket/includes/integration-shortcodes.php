<?php
/**
 * Integration Shortcode Functions
 *
 * @package WP_TICKET_COM
 * @since WPAS 4.0
 */
if (!defined('ABSPATH')) exit;
add_shortcode('private_search_ticket', 'wp_ticket_com_get_integ_private_search_ticket');
/**
 * Display integration shortcode or no access msg
 * @since WPAS 4.0
 *
 * @return string $layout or $no_access_msg
 */
function wp_ticket_com_get_integ_private_search_ticket($atts) {
	$no_access_msg = __('You are not authorized to access to this page. Please log in or contact the site administrator.', 'wp-ticket-com');
	$access_views = get_option('wp_ticket_com_access_views', Array());
	if (!current_user_can('view_private_search_ticket') && !empty($access_views['integration']) && in_array('private_search_ticket', $access_views['integration'])) {
		return $no_access_msg;
	} else {
		wp_enqueue_script('jquery');
		add_action('wp_footer', 'wp_ticket_com_enq_allview');
		if (!empty($atts) && !empty($atts['filter'])) {
			$shc_filter = "private_search_ticket_filter";
			global $$shc_filter;
			$$shc_filter = $atts['filter'];
		}
		ob_start();
		emd_get_template_part('wp-ticket-com', 'integration', 'private-search-ticket');
		$layout = ob_get_clean();
		return $layout;
	}
}
add_shortcode('private_submit_ticket', 'wp_ticket_com_get_integ_private_submit_ticket');
/**
 * Display integration shortcode or no access msg
 * @since WPAS 4.0
 *
 * @return string $layout or $no_access_msg
 */
function wp_ticket_com_get_integ_private_submit_ticket($atts) {
	$no_access_msg = __('You are not authorized to access to this page. Please log in or contact the site administrator.', 'wp-ticket-com');
	$access_views = get_option('wp_ticket_com_access_views', Array());
	if (!current_user_can('view_private_submit_ticket') && !empty($access_views['integration']) && in_array('private_submit_ticket', $access_views['integration'])) {
		return $no_access_msg;
	} else {
		wp_enqueue_script('jquery');
		add_action('wp_footer', 'wp_ticket_com_enq_allview');
		if (!empty($atts) && !empty($atts['filter'])) {
			$shc_filter = "private_submit_ticket_filter";
			global $$shc_filter;
			$$shc_filter = $atts['filter'];
		}
		ob_start();
		emd_get_template_part('wp-ticket-com', 'integration', 'private-submit-ticket');
		$layout = ob_get_clean();
		return $layout;
	}
}
